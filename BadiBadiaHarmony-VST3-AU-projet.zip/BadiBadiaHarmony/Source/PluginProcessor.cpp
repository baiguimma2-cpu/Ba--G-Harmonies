#include "PluginProcessor.h"
#include "PluginEditor.h"

namespace
{
    constexpr int kAna = 1024;
    constexpr float kOffset[HarmonyProcessor::numVoices] = { 0.f, 3.5f, 7.f, 12.f, -3.5f, -12.f };
    constexpr float kPan[HarmonyProcessor::numVoices] = { -0.3f, 0.5f, -0.5f, 0.8f, -0.8f, 0.2f };

    constexpr int bits (std::initializer_list<int> l)
    {
        int r = 0;
        for (int x : l) r |= (1 << x);
        return r;
    }

    // Gammes : notes (demi-tons depuis la tonique) sous forme de masque de 12 bits
    constexpr int kMask[HarmonyProcessor::numScales] = {
        bits ({ 0, 2, 4, 5, 7, 9, 11 }),   // Majeur
        bits ({ 0, 2, 3, 5, 7, 8, 10 }),   // Mineur
        bits ({ 0, 2, 3, 5, 7, 8, 11 }),   // Mineur harmonique
        bits ({ 0, 2, 3, 5, 7, 9, 11 }),   // Mineur mélodique
        bits ({ 0, 2, 3, 5, 7, 9, 10 }),   // Dorien
        bits ({ 0, 1, 3, 5, 7, 8, 10 }),   // Phrygien
        bits ({ 0, 2, 4, 6, 7, 9, 11 }),   // Lydien
        bits ({ 0, 2, 4, 5, 7, 9, 10 }),   // Mixolydien
        bits ({ 0, 2, 4, 7, 9 }),          // Pentatonique majeure
        bits ({ 0, 3, 5, 7, 10 }),         // Pentatonique mineure
        bits ({ 0, 3, 5, 6, 7, 10 }),      // Blues
        bits ({ 0, 1, 4, 5, 7, 8, 10 }),   // Hijaz (arabe)
        bits ({ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 }) // Chromatique
    };

    const char* const kScaleNames[HarmonyProcessor::numScales] = {
        "Majeur", "Mineur", "Mineur harm.", "Mineur mél.", "Dorien", "Phrygien", "Lydien",
        "Mixolydien", "Pent. majeure", "Pent. mineure", "Blues", "Hijaz (arabe)", "Chromatique" };

    const char* const kNames[12] = { "Do", "Do♯", "Ré", "Ré♯", "Mi", "Fa", "Fa♯", "Sol", "Sol♯", "La", "La♯", "Si" };

    // Note de la gamme la plus proche de x (à égalité : la plus basse)
    int nearestInScale (float x, int key, int mask)
    {
        const int c = (int) std::floor (x);
        int best = c;
        float bd = 1e9f;
        for (int n = c - 8; n <= c + 9; ++n)
        {
            const int pc = (((n - key) % 12) + 12) % 12;
            if (((mask >> pc) & 1) == 0) continue;
            const float e = std::abs ((float) n - x);
            if (e < bd - 1e-4f) { bd = e; best = n; }
        }
        return best;
    }

    juce::String fDb (float v)    { return juce::String (v, 1) + " dB"; }
    juce::String fPct (float v)   { return juce::String (juce::roundToInt (v * 100.f)) + " %"; }
    juce::String fRatio (float v) { return juce::String (v, 1) + ":1"; }
    juce::String fMs (float v)    { return juce::String (juce::roundToInt (v)) + " ms"; }

    void addFloat (juce::AudioProcessorValueTreeState::ParameterLayout& L, const juce::String& id,
                   const juce::String& name, float lo, float hi, float def, float skew,
                   juce::String (*fmt) (float))
    {
        juce::NormalisableRange<float> r (lo, hi, 0.f, skew);
        L.add (std::make_unique<juce::AudioParameterFloat> (
            juce::ParameterID { id, 1 }, name, r, def,
            juce::AudioParameterFloatAttributes().withStringFromValueFunction ([fmt] (float v, int) { return fmt (v); })));
    }
}

// ---------------------------------------------------------------- Biquad
void Biquad::design (int band, float sr, float dB)
{
    const float freqs[4] = { 120.f, 500.f, 3000.f, 10000.f };
    const float f = juce::jmin (freqs[band], 0.45f * sr);
    const float A = std::pow (10.f, dB / 40.f);
    const float w0 = 2.f * juce::MathConstants<float>::pi * f / sr;
    const float cs = std::cos (w0), sn = std::sin (w0);
    float B0, B1, B2, A0, A1, A2;

    if (band == 1 || band == 2)   // cloche
    {
        const float alpha = sn / (2.f * 0.9f);
        B0 = 1.f + alpha * A;  B1 = -2.f * cs;  B2 = 1.f - alpha * A;
        A0 = 1.f + alpha / A;  A1 = -2.f * cs;  A2 = 1.f - alpha / A;
    }
    else
    {
        const float alpha = sn * 0.5f * 1.41421356f;
        const float t = 2.f * std::sqrt (A) * alpha;
        if (band == 0)            // plateau graves
        {
            B0 = A * ((A + 1.f) - (A - 1.f) * cs + t);
            B1 = 2.f * A * ((A - 1.f) - (A + 1.f) * cs);
            B2 = A * ((A + 1.f) - (A - 1.f) * cs - t);
            A0 = (A + 1.f) + (A - 1.f) * cs + t;
            A1 = -2.f * ((A - 1.f) + (A + 1.f) * cs);
            A2 = (A + 1.f) + (A - 1.f) * cs - t;
        }
        else                      // plateau aigus
        {
            B0 = A * ((A + 1.f) + (A - 1.f) * cs + t);
            B1 = -2.f * A * ((A - 1.f) + (A + 1.f) * cs);
            B2 = A * ((A + 1.f) + (A - 1.f) * cs - t);
            A0 = (A + 1.f) - (A - 1.f) * cs + t;
            A1 = 2.f * ((A - 1.f) - (A + 1.f) * cs);
            A2 = (A + 1.f) - (A - 1.f) * cs - t;
        }
    }
    const float inv = 1.f / A0;
    b0 = B0 * inv;  b1 = B1 * inv;  b2 = B2 * inv;
    a1 = A1 * inv;  a2 = A2 * inv;
}

// ---------------------------------------------------------------- Noms
juce::String HarmonyProcessor::pitchClassName (int pc)
{
    return juce::String::fromUTF8 (kNames[((pc % 12) + 12) % 12]);
}

juce::String HarmonyProcessor::noteName (float midi)
{
    const int r = juce::roundToInt (midi);
    return pitchClassName (r) + juce::String ((int) std::floor (r / 12.0) - 1);
}

juce::String HarmonyProcessor::scaleName (int index)
{
    return juce::String::fromUTF8 (kScaleNames[juce::jlimit (0, numScales - 1, index)]);
}

// ---------------------------------------------------------------- Paramètres
juce::AudioProcessorValueTreeState::ParameterLayout HarmonyProcessor::createLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout L;

    juce::StringArray keys, scales;
    for (int i = 0; i < 12; ++i) keys.add (pitchClassName (i));
    for (int i = 0; i < numScales; ++i) scales.add (scaleName (i));
    L.add (std::make_unique<juce::AudioParameterChoice> (juce::ParameterID { "key", 1 }, "Tonalite", keys, 0));
    L.add (std::make_unique<juce::AudioParameterChoice> (juce::ParameterID { "scale", 1 }, "Gamme", scales, 0));

    for (int i = 0; i < numVoices; ++i)
    {
        L.add (std::make_unique<juce::AudioParameterBool> (juce::ParameterID { "v" + juce::String (i), 1 },
                                                           "Voix " + juce::String (i + 1), i == 1 || i == 2));
        addFloat (L, "lv" + juce::String (i), "Niveau voix " + juce::String (i + 1), 0.f, 1.f, 0.85f, 1.f, fPct);
    }

    addFloat (L, "dry", "Ma voix", 0.f, 1.f, 1.f, 1.f, fPct);
    addFloat (L, "wet", "Harmonies", 0.f, 1.f, 0.7f, 1.f, fPct);
    addFloat (L, "width", "Largeur", 0.f, 1.f, 0.8f, 1.f, fPct);

    const char* sfx[4] = { "lo", "lm", "hm", "hi" };
    const char* nm[4] = { "Graves", "Corps", "Presence", "Air" };
    for (int b = 0; b < 4; ++b)
    {
        addFloat (L, juce::String ("m_") + sfx[b], juce::String ("Voix ") + nm[b], -12.f, 12.f, 0.f, 1.f, fDb);
        addFloat (L, juce::String ("h_") + sfx[b], juce::String ("Harmonies ") + nm[b], -12.f, 12.f, 0.f, 1.f, fDb);
    }

    L.add (std::make_unique<juce::AudioParameterBool> (juce::ParameterID { "c_on", 1 }, "Compresseur", true));
    addFloat (L, "c_thr", "Seuil", -40.f, 0.f, -18.f, 1.f, fDb);
    addFloat (L, "c_ratio", "Ratio", 1.f, 12.f, 3.f, 0.5f, fRatio);
    addFloat (L, "c_att", "Attaque", 1.f, 100.f, 12.f, 0.5f, fMs);
    addFloat (L, "c_rel", "Relache", 20.f, 500.f, 140.f, 0.5f, fMs);
    addFloat (L, "c_mk", "Gain", 0.f, 12.f, 2.f, 1.f, fDb);
    return L;
}

HarmonyProcessor::HarmonyProcessor()
    : AudioProcessor (BusesProperties()
                          .withInput ("Input", juce::AudioChannelSet::stereo(), true)
                          .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "STATE", createLayout())
{
    pKey = apvts.getRawParameterValue ("key");
    pScale = apvts.getRawParameterValue ("scale");
    pDry = apvts.getRawParameterValue ("dry");
    pWet = apvts.getRawParameterValue ("wet");
    pWidth = apvts.getRawParameterValue ("width");
    for (int i = 0; i < numVoices; ++i)
    {
        pVoice[i] = apvts.getRawParameterValue ("v" + juce::String (i));
        pLv[i] = apvts.getRawParameterValue ("lv" + juce::String (i));
        voiceMidi[i].store (0.f);
    }
    const char* sfx[4] = { "lo", "lm", "hm", "hi" };
    for (int b = 0; b < 4; ++b)
    {
        pEqM[b] = apvts.getRawParameterValue (juce::String ("m_") + sfx[b]);
        pEqH[b] = apvts.getRawParameterValue (juce::String ("h_") + sfx[b]);
    }
    pCOn = apvts.getRawParameterValue ("c_on");
    pCThr = apvts.getRawParameterValue ("c_thr");
    pCRatio = apvts.getRawParameterValue ("c_ratio");
    pCAtt = apvts.getRawParameterValue ("c_att");
    pCRel = apvts.getRawParameterValue ("c_rel");
    pCMk = apvts.getRawParameterValue ("c_mk");
}

bool HarmonyProcessor::isBusesLayoutSupported (const BusesLayout& l) const
{
    const auto& out = l.getMainOutputChannelSet();
    if (out != juce::AudioChannelSet::mono() && out != juce::AudioChannelSet::stereo()) return false;
    return l.getMainInputChannelSet() == out;
}

void HarmonyProcessor::prepareToPlay (double sr, int)
{
    sampleRate = sr;
    Wf = (float) (0.05 * sr);                       // fenêtre de 50 ms
    const int W = (int) Wf;
    ring.assign ((size_t) juce::nextPowerOfTwo (W * 2 + 8), 0.f);
    ringMask = (int) ring.size() - 1;
    writePos = 0;

    dryN = juce::jmax (1, W / 2);                    // voix directe alignée sur les harmonies
    dryL.assign ((size_t) dryN, 0.f);
    dryR.assign ((size_t) dryN, 0.f);
    dryPos = 0;
    setLatencySamples (dryN);

    decFactor = juce::jmax (1, (int) std::round (sr / 22050.0));
    anaBuf.assign (kAna, 0.f);
    tmp.assign (kAna, 0.f);
    corr.assign (512, 0.f);
    anaPos = decCount = hop = unvoiced = 0;
    decAcc = 0.f;
    haveMidi = false;

    for (auto& v : voices)
    {
        v.phase = 0.f;
        v.ratio.reset (sr, 0.03);
        v.ratio.setCurrentAndTargetValue (1.f);
        v.gain.reset (sr, 0.03);
        v.gain.setCurrentAndTargetValue (0.f);
    }
    dryS.reset (sr, 0.02);
    wetS.reset (sr, 0.02);
    dryS.setCurrentAndTargetValue (pDry->load());
    wetS.setCurrentAndTargetValue (0.f);

    for (int c = 0; c < 2; ++c)
        for (int b = 0; b < 4; ++b) { eqM[c][b] = Biquad(); eqH[c][b] = Biquad(); }
    for (int b = 0; b < 4; ++b) { lastM[b] = 1000.f; lastH[b] = 1000.f; }
    grState = 0.f;
}

inline float HarmonyProcessor::readDelay (float d) const noexcept
{
    const float rp = (float) writePos - d;
    const int i0 = (int) std::floor (rp);
    const float fr = rp - (float) i0;
    const float a = ring[(size_t) (i0 & ringMask)];
    const float b = ring[(size_t) ((i0 + 1) & ringMask)];
    return a + (b - a) * fr;
}

void HarmonyProcessor::refreshEq (std::atomic<float>* const* params, Biquad (&eq)[2][4], float (&last)[4], bool& on)
{
    on = false;
    for (int b = 0; b < 4; ++b)
    {
        const float g = params[b]->load();
        if (std::abs (g) > 0.05f) on = true;
        if (std::abs (g - last[b]) > 1e-4f)
        {
            last[b] = g;
            for (int c = 0; c < 2; ++c) eq[c][b].design (b, (float) sampleRate, g);
        }
    }
}

void HarmonyProcessor::updateTargets()
{
    if (! haveMidi) return;
    const int mask = kMask[scaleV];
    const int base = nearestInScale (curMidi, keyV, mask);
    for (int v = 0; v < numVoices; ++v)
    {
        const int t = (v == 0) ? base : nearestInScale ((float) base + kOffset[v], keyV, mask);
        const float semis = juce::jlimit (-14.f, 14.f, (float) t - curMidi);
        const float r = std::exp2 (semis / 12.f);
        if (enabled[v]) voices[v].ratio.setTargetValue (r);
        else voices[v].ratio.setCurrentAndTargetValue (r);
        voiceMidi[v].store ((float) t);
    }
}

void HarmonyProcessor::feedDetector (float x)
{
    decAcc += x;
    if (++decCount < decFactor) return;
    anaBuf[(size_t) anaPos] = decAcc / (float) decFactor;
    anaPos = (anaPos + 1) & (kAna - 1);
    decAcc = 0.f;
    decCount = 0;
    if (++hop >= 256) { hop = 0; runDetect(); }
}

void HarmonyProcessor::runDetect()
{
    float e = 0.f;
    for (int i = 0; i < kAna; ++i)
    {
        const float s = anaBuf[(size_t) ((anaPos + i) & (kAna - 1))];
        tmp[(size_t) i] = s;
        e += s * s;
    }
    if (std::sqrt (e / (float) kAna) < 0.01f)
    {
        if (++unvoiced > 10) detectedMidi.store (-1.f);
        return;
    }

    const float ar = (float) (sampleRate / decFactor);
    const int lo = juce::jmax (2, (int) (ar / 800.f));
    const int hi = juce::jmin ((int) (ar / 80.f), 400);
    const int N = kAna - hi;
    float mx = 0.f;
    for (int l = lo; l <= hi; ++l)
    {
        float s = 0.f;
        for (int i = 0; i < N; i += 2) s += tmp[(size_t) i] * tmp[(size_t) (i + l)];
        corr[(size_t) l] = s;
        if (s > mx) mx = s;
    }
    if (mx <= 0.f) return;

    for (int l = lo + 1; l < hi; ++l)
    {
        const float a = corr[(size_t) (l - 1)], b = corr[(size_t) l], g = corr[(size_t) (l + 1)];
        if (b > 0.88f * mx && b >= a && b >= g)
        {
            const float den = a - 2.f * b + g;
            const float p = den != 0.f ? 0.5f * (a - g) / den : 0.f;
            const float m = 69.f + 12.f * std::log2 (ar / ((float) l + p) / 440.f);
            unvoiced = 0;
            curMidi = (! haveMidi || std::abs (m - curMidi) > 1.f) ? m : curMidi + (m - curMidi) * 0.5f;
            haveMidi = true;
            detectedMidi.store (curMidi);
            updateTargets();
            return;
        }
    }
}

void HarmonyProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    const int n = buffer.getNumSamples();
    const int nch = juce::jmin (2, buffer.getNumChannels());
    for (int ch = getTotalNumInputChannels(); ch < getTotalNumOutputChannels(); ++ch)
        buffer.clear (ch, 0, n);
    if (nch == 0 || ring.empty()) return;

    keyV = (int) pKey->load();
    scaleV = juce::jlimit (0, numScales - 1, (int) pScale->load());
    const float width = pWidth->load();

    int active = 0;
    for (int v = 0; v < numVoices; ++v)
    {
        enabled[v] = pVoice[v]->load() > 0.5f;
        if (enabled[v]) ++active;
        voices[v].gain.setTargetValue (enabled[v] ? pLv[v]->load() : 0.f);
        const float ang = (kPan[v] * width + 1.f) * juce::MathConstants<float>::pi * 0.25f;
        panL[v] = std::cos (ang);
        panR[v] = std::sin (ang);
    }
    updateTargets();
    dryS.setTargetValue (pDry->load());
    wetS.setTargetValue (pWet->load() * 0.85f / std::sqrt ((float) juce::jmax (1, active)));

    refreshEq (pEqM, eqM, lastM, eqMOn);
    refreshEq (pEqH, eqH, lastH, eqHOn);

    const bool cOn = pCOn->load() > 0.5f;
    const float sr = (float) sampleRate;
    const float cThr = pCThr->load();
    const float cRatio = juce::jmax (1.f, pCRatio->load());
    const float mkLin = std::pow (10.f, pCMk->load() / 20.f);
    const float attC = std::exp (-1.f / (juce::jmax (0.5f, pCAtt->load()) * 0.001f * sr));
    const float relC = std::exp (-1.f / (juce::jmax (5.f, pCRel->load()) * 0.001f * sr));
    float grMax = 0.f;

    float* l = buffer.getWritePointer (0);
    float* r = nch > 1 ? buffer.getWritePointer (1) : nullptr;

    for (int i = 0; i < n; ++i)
    {
        const float inL = l[i];
        const float inR = r != nullptr ? r[i] : inL;
        const float mono = r != nullptr ? 0.5f * (inL + inR) : inL;

        ring[(size_t) writePos] = mono;
        feedDetector (mono);

        float dL = dryL[(size_t) dryPos], dR = dryR[(size_t) dryPos];
        dryL[(size_t) dryPos] = inL;
        dryR[(size_t) dryPos] = inR;
        if (++dryPos >= dryN) dryPos = 0;

        // Égaliseur de la voix principale
        if (eqMOn)
            for (int b = 0; b < 4; ++b)
            {
                dL = eqM[0][b].process (dL);
                if (r != nullptr) dR = eqM[1][b].process (dR);
            }

        // Somme des voix d'harmonie
        float hl = 0.f, hr = 0.f;
        for (int v = 0; v < numVoices; ++v)
        {
            auto& vc = voices[v];
            if (! vc.gain.isSmoothing() && vc.gain.getTargetValue() == 0.f) continue;

            const float g = vc.gain.getNextValue();
            const float ratio = vc.ratio.getNextValue();
            vc.phase += (1.f - ratio) / Wf;
            vc.phase -= std::floor (vc.phase);
            float p2 = vc.phase + 0.5f;
            if (p2 >= 1.f) p2 -= 1.f;
            const float s = std::sin (juce::MathConstants<float>::pi * vc.phase);
            const float w1 = s * s;
            const float y = (readDelay (1.f + vc.phase * Wf) * w1
                             + readDelay (1.f + p2 * Wf) * (1.f - w1)) * g;
            hl += y * panL[v];
            hr += y * panR[v];
        }

        // Égaliseur puis compresseur des harmonies
        if (eqHOn)
            for (int b = 0; b < 4; ++b)
            {
                hl = eqH[0][b].process (hl);
                hr = eqH[1][b].process (hr);
            }

        if (cOn)
        {
            const float lev = juce::jmax (std::abs (hl), std::abs (hr));
            const float over = 20.f * std::log10 (lev + 1e-6f) - cThr;
            const float target = over > 0.f ? over * (1.f - 1.f / cRatio) : 0.f;
            const float cf = target > grState ? attC : relC;
            grState = cf * grState + (1.f - cf) * target;
            const float gn = std::exp (-grState * 0.1151293f) * mkLin;
            hl *= gn;
            hr *= gn;
            grMax = juce::jmax (grMax, grState);
        }

        const float dg = dryS.getNextValue(), wg = wetS.getNextValue();
        if (r != nullptr) { l[i] = dL * dg + hl * wg; r[i] = dR * dg + hr * wg; }
        else              { l[i] = dL * dg + 0.5f * (hl + hr) * wg; }

        writePos = (writePos + 1) & ringMask;
    }

    grMeter.store (grMax);
    level.store (juce::jmin (1.f, buffer.getMagnitude (0, n)));
}

juce::AudioProcessorEditor* HarmonyProcessor::createEditor() { return new HarmonyEditor (*this); }

void HarmonyProcessor::getStateInformation (juce::MemoryBlock& dest)
{
    auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml (state.createXml());
    copyXmlToBinary (*xml, dest);
}

void HarmonyProcessor::setStateInformation (const void* data, int size)
{
    std::unique_ptr<juce::XmlElement> xml (getXmlFromBinary (data, size));
    if (xml != nullptr && xml->hasTagName (apvts.state.getType()))
        apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new HarmonyProcessor(); }

#pragma once
#include <JuceHeader.h>

// Filtre biquad (égaliseur 4 bandes : graves, corps, présence, air)
struct Biquad
{
    float b0 = 1.f, b1 = 0.f, b2 = 0.f, a1 = 0.f, a2 = 0.f, z1 = 0.f, z2 = 0.f;

    inline float process (float x) noexcept
    {
        const float y = b0 * x + z1;
        z1 = b1 * x - a1 * y + z2;
        z2 = b2 * x - a2 * y;
        return y;
    }
    void design (int band, float sampleRate, float gainDb);
};

// Baï-G harmonies — génère des harmonies à partir d'une seule voix.
// DSP : détection de hauteur + transposeurs granulaires + égaliseurs + compresseur d'harmonies.
class HarmonyProcessor : public juce::AudioProcessor
{
public:
    static constexpr int numVoices = 6;
    static constexpr int numScales = 13;

    HarmonyProcessor();
    ~HarmonyProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout&) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    using AudioProcessor::processBlock;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "Badi-badia Harmony"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock&) override;
    void setStateInformation (const void*, int) override;

    static juce::String pitchClassName (int pc);
    static juce::String noteName (float midi);
    static juce::String scaleName (int index);

    juce::AudioProcessorValueTreeState apvts;

    // Lus par l'éditeur (affichage)
    std::atomic<float> detectedMidi { -1.f };
    std::atomic<float> level { 0.f };
    std::atomic<float> grMeter { 0.f };
    std::atomic<float> voiceMidi[numVoices];

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();
    void feedDetector (float x);
    void runDetect();
    void updateTargets();
    void refreshEq (std::atomic<float>* const* params, Biquad (&eq)[2][4], float (&last)[4], bool& on);
    float readDelay (float d) const noexcept;

    std::atomic<float>* pKey = nullptr;
    std::atomic<float>* pScale = nullptr;
    std::atomic<float>* pDry = nullptr;
    std::atomic<float>* pWet = nullptr;
    std::atomic<float>* pWidth = nullptr;
    std::atomic<float>* pVoice[numVoices] {};
    std::atomic<float>* pLv[numVoices] {};
    std::atomic<float>* pEqM[4] {};
    std::atomic<float>* pEqH[4] {};
    std::atomic<float>* pCOn = nullptr;
    std::atomic<float>* pCThr = nullptr;
    std::atomic<float>* pCRatio = nullptr;
    std::atomic<float>* pCAtt = nullptr;
    std::atomic<float>* pCRel = nullptr;
    std::atomic<float>* pCMk = nullptr;

    double sampleRate = 44100.0;
    float Wf = 2205.f;
    int dryN = 1;

    std::vector<float> ring, dryL, dryR, anaBuf, tmp, corr;
    int ringMask = 0, writePos = 0, dryPos = 0;
    int decFactor = 2, decCount = 0, anaPos = 0, hop = 0, unvoiced = 0;
    float decAcc = 0.f, curMidi = 0.f;
    bool haveMidi = false;

    int keyV = 0, scaleV = 0;
    bool enabled[numVoices] {};

    struct Voice
    {
        float phase = 0.f;
        juce::SmoothedValue<float> ratio, gain;
    };
    Voice voices[numVoices];
    juce::SmoothedValue<float> dryS, wetS;
    float panL[numVoices] {}, panR[numVoices] {};

    Biquad eqM[2][4], eqH[2][4];
    float lastM[4] {}, lastH[4] {};
    bool eqMOn = false, eqHOn = false;
    float grState = 0.f;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (HarmonyProcessor)
};

#include "PluginEditor.h"
#include "Presets.h"

namespace
{
    const juce::Colour kGold   { 0xfff5c451 };
    const juce::Colour kPink   { 0xffec4899 };
    const juce::Colour kViolet { 0xff8b5cf6 };
    const juce::Colour kCard   { 0xff1d1a35 };
    const juce::Colour kLine   { 0xff2a2645 };
    const juce::Colour kGrey   { 0xffb9b4d9 };

    juce::Font F (float h, bool bold = false)
    {
        return juce::Font (juce::FontOptions (h, bold ? juce::Font::bold : juce::Font::plain));
    }

    const char* const kVoiceNames[HarmonyProcessor::numVoices] =
        { "Unisson", "Tierce ↑", "Quinte ↑", "Octave ↑", "Tierce ↓", "Octave ↓" };

    struct KnobDef { const char* id; const char* title; };
    const KnobDef kKnobs[16] = {
        { "dry", "Ma voix" }, { "wet", "Harmonies" }, { "width", "Largeur" },
        { "m_lo", "Graves" }, { "m_lm", "Corps" }, { "m_hm", "Présence" }, { "m_hi", "Air" },
        { "h_lo", "Graves" }, { "h_lm", "Corps" }, { "h_hm", "Présence" }, { "h_hi", "Air" },
        { "c_thr", "Seuil" }, { "c_ratio", "Ratio" }, { "c_att", "Attaque" }, { "c_rel", "Relâche" }, { "c_mk", "Gain" } };

    void heading (juce::Graphics& g, const juce::String& t, int x, int y, int w)
    {
        g.setColour (kGold);
        g.fillRoundedRectangle ((float) x, (float) y + 1.f, 3.f, 13.f, 1.5f);
        g.setColour (kGrey);
        g.setFont (F (12.f, true));
        g.drawText (t, x + 9, y, w - 9, 15, juce::Justification::centredLeft);
    }

    // Logo « Baï-G harmonies » : monogramme B + G.
    // Le G est un anneau dont la barre est une onde sonore ; deux anneaux « fantômes »
    // derrière lui représentent les harmonies (une voix qui devient plusieurs).
    void drawLogo (juce::Graphics& g, juce::Rectangle<float> r)
    {
        const float s = r.getWidth() / 100.f;
        const auto tf = juce::AffineTransform::scale (s).translated (r.getX(), r.getY());
        const float pi = juce::MathConstants<float>::pi;
        const float corner = r.getWidth() * 0.26f;

        g.setGradientFill (juce::ColourGradient (juce::Colour (0xff2a1458), r.getX(), r.getY(),
                                                 kPink, r.getRight(), r.getBottom(), false));
        g.fillRoundedRectangle (r, corner);
        g.setGradientFill (juce::ColourGradient (juce::Colours::white.withAlpha (0.20f), r.getX(), r.getY(),
                                                 juce::Colours::transparentWhite, r.getX(), r.getCentreY(), false));
        g.fillRoundedRectangle (r.withHeight (r.getHeight() * 0.55f), corner);
        g.setColour (juce::Colours::white.withAlpha (0.28f));
        g.drawRoundedRectangle (r.reduced (0.5f), corner, 1.f);

        auto ring = [pi] (float dx, float dy)
        {
            juce::Path p;
            p.addCentredArc (64.f + dx, 49.5f + dy, 18.f, 18.f, 0.f, pi * 0.5f, pi * 2.25f, true);
            return p;
        };
        const auto thin = juce::PathStrokeType (4.f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded);
        const auto bold = juce::PathStrokeType (6.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded);

        // anneaux fantômes (harmonies)
        g.setColour (kViolet.withAlpha (0.45f));
        g.strokePath (ring (7.5f, 5.f), thin, tf);
        g.setColour (kPink.withAlpha (0.55f));
        g.strokePath (ring (4.f, 2.5f), thin, tf);

        // B
        juce::Path b;
        b.startNewSubPath (17.f, 68.f);
        b.lineTo (17.f, 31.f);
        b.lineTo (26.f, 31.f);
        b.addCentredArc (26.f, 40.25f, 9.25f, 9.25f, 0.f, 0.f, pi, false);
        b.lineTo (17.f, 49.5f);
        b.startNewSubPath (26.f, 49.5f);
        b.addCentredArc (26.f, 58.75f, 9.25f, 9.25f, 0.f, 0.f, pi, false);
        b.lineTo (17.f, 68.f);

        // G : anneau + barre en forme d'onde
        juce::Path gp = ring (0.f, 0.f);
        juce::Path wave;
        wave.startNewSubPath (82.f, 49.5f);
        wave.quadraticTo (77.5f, 40.5f, 73.f, 49.5f);
        wave.quadraticTo (68.5f, 58.5f, 64.f, 49.5f);

        g.setGradientFill (juce::ColourGradient (juce::Colour (0xfffff3c4), 0.f, r.getY() + 28.f * s,
                                                 kGold, 0.f, r.getY() + 72.f * s, false));
        g.strokePath (b, bold, tf);
        g.strokePath (gp, bold, tf);
        g.strokePath (wave, juce::PathStrokeType (4.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded), tf);

        // tréma du « ï » : deux petits points
        g.fillEllipse (r.getX() + 12.f * s, r.getY() + 17.f * s, 4.f * s, 4.f * s);
        g.fillEllipse (r.getX() + 20.f * s, r.getY() + 17.f * s, 4.f * s, 4.f * s);
    }
}

// ---------------------------------------------------------------- Look & feel
BBLookAndFeel::BBLookAndFeel()
{
    setColour (juce::ComboBox::backgroundColourId, kCard);
    setColour (juce::ComboBox::textColourId, juce::Colours::white);
    setColour (juce::ComboBox::outlineColourId, kLine);
    setColour (juce::ComboBox::arrowColourId, kGold);
    setColour (juce::PopupMenu::backgroundColourId, juce::Colour (0xff151326));
    setColour (juce::PopupMenu::textColourId, juce::Colours::white);
    setColour (juce::PopupMenu::headerTextColourId, kGold);
    setColour (juce::PopupMenu::highlightedBackgroundColourId, kViolet);
    setColour (juce::Slider::textBoxTextColourId, juce::Colours::white);
    setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    setColour (juce::TextButton::textColourOffId, juce::Colours::white);
    setColour (juce::TextButton::textColourOnId, juce::Colours::white);
}

juce::Font BBLookAndFeel::getTextButtonFont (juce::TextButton&, int) { return F (13.f); }

void BBLookAndFeel::drawToggleButton (juce::Graphics& g, juce::ToggleButton& b, bool hl, bool)
{
    auto r = b.getLocalBounds().toFloat().reduced (1.f);
    const bool on = b.getToggleState();
    const bool chip = (bool) b.getProperties()["chip"];
    const float rad = chip ? 14.f : 10.f;
    if (on)
        g.setGradientFill (juce::ColourGradient (kViolet.withAlpha (0.35f), r.getX(), r.getY(),
                                                 kPink.withAlpha (0.35f), r.getRight(), r.getBottom(), false));
    else
        g.setColour (hl ? kCard.brighter (0.1f) : kCard);
    g.fillRoundedRectangle (r, rad);
    g.setColour (on ? kViolet : kLine);
    g.drawRoundedRectangle (r, rad, 1.4f);

    auto t = chip ? r.withTrimmedBottom (18.f) : r;
    g.setColour (juce::Colours::white);
    g.setFont (F (chip ? 15.f : 13.f, ! chip));
    g.drawText (b.getButtonText(), t.reduced (14.f, 0.f), chip ? juce::Justification::centredLeft : juce::Justification::centred);
    g.setColour (kGold);
    g.setFont (F (14.f, true));
    g.drawText (b.getProperties()["note"].toString(), t.reduced (14.f, 0.f), juce::Justification::centredRight);
}

void BBLookAndFeel::drawRotarySlider (juce::Graphics& g, int x, int y, int w, int h, float pos,
                                      float start, float end, juce::Slider& s)
{
    auto b = juce::Rectangle<float> ((float) x, (float) y, (float) w, (float) h).reduced (8.f);
    const float r = juce::jmin (b.getWidth(), b.getHeight()) * 0.5f;
    const auto c = b.getCentre();
    const float tr = r - 5.f;
    const float ang = start + pos * (end - start);
    const bool bipolar = s.getMinimum() < 0.0 && s.getMaximum() > 0.0;
    const float from = bipolar ? start + 0.5f * (end - start) : start;
    const juce::PathStrokeType st (6.f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded);

    juce::Path track, val;
    track.addCentredArc (c.x, c.y, tr, tr, 0.f, start, end, true);
    val.addCentredArc (c.x, c.y, tr, tr, 0.f, juce::jmin (from, ang), juce::jmax (from, ang), true);
    g.setColour (kLine);
    g.strokePath (track, st);
    g.setGradientFill (juce::ColourGradient (kGold, c.x - tr, c.y, kPink, c.x + tr, c.y, false));
    g.strokePath (val, st);

    g.setColour (kCard);
    g.fillEllipse (juce::Rectangle<float> (tr * 1.25f, tr * 1.25f).withCentre (c));
    juce::Path p;
    p.addRoundedRectangle (-1.5f, -tr * 0.62f, 3.f, tr * 0.36f, 1.5f);
    g.setColour (juce::Colours::white);
    g.fillPath (p, juce::AffineTransform::rotation (ang).translated (c.x, c.y));
}

void BBLookAndFeel::drawLinearSlider (juce::Graphics& g, int x, int y, int w, int h, float pos,
                                      float, float, juce::Slider::SliderStyle, juce::Slider&)
{
    const float cy = (float) y + (float) h * 0.5f;
    g.setColour (kLine);
    g.fillRoundedRectangle ((float) x, cy - 2.f, (float) w, 4.f, 2.f);
    g.setGradientFill (juce::ColourGradient (kGold, (float) x, cy, kPink, (float) (x + w), cy, false));
    g.fillRoundedRectangle ((float) x, cy - 2.f, juce::jmax (0.f, pos - (float) x), 4.f, 2.f);
    g.setColour (juce::Colours::white);
    g.fillEllipse (pos - 5.f, cy - 5.f, 10.f, 10.f);
}

void BBLookAndFeel::drawButtonBackground (juce::Graphics& g, juce::Button& b, const juce::Colour&,
                                          bool hl, bool down)
{
    auto r = b.getLocalBounds().toFloat().reduced (1.f);
    const bool on = b.getToggleState();
    const float rad = r.getHeight() * 0.5f;
    if (on)
        g.setGradientFill (juce::ColourGradient (kViolet.withAlpha (0.7f), r.getX(), r.getY(),
                                                 kPink.withAlpha (0.7f), r.getRight(), r.getBottom(), false));
    else
        g.setColour (down ? kViolet.withAlpha (0.5f) : (hl ? kCard.brighter (0.15f) : kCard));
    g.fillRoundedRectangle (r, rad);
    g.setColour (on ? kGold : (hl ? kGold.withAlpha (0.7f) : kLine));
    g.drawRoundedRectangle (r, rad, on ? 1.6f : 1.2f);
}

// ---------------------------------------------------------------- Éditeur
HarmonyEditor::HarmonyEditor (HarmonyProcessor& p) : AudioProcessorEditor (&p), proc (p)
{
    setLookAndFeel (&laf);
    setSize (860, 656);

    // Préréglages (menu classé par contexte + flèches)
    presetBox.setTextWhenNothingSelected (juce::String::fromUTF8 ("Choisir un préréglage…"));
    const char* lastCtx = nullptr;
    for (int i = 0; i < kNumPresets; ++i)
    {
        if (lastCtx == nullptr || std::strcmp (lastCtx, kPresets[i].ctx) != 0)
        {
            presetBox.addSectionHeading (juce::String::fromUTF8 (kPresets[i].ctx));
            lastCtx = kPresets[i].ctx;
        }
        presetBox.addItem (juce::String::fromUTF8 (kPresets[i].name), i + 1);
    }
    presetBox.onChange = [this] { const int id = presetBox.getSelectedId(); if (id > 0) applyPreset (id - 1); };
    presetPrev.setButtonText ("<");
    presetNext.setButtonText (">");
    presetPrev.onClick = [this]
    {
        const int id = presetBox.getSelectedId();
        presetBox.setSelectedId (id <= 1 ? kNumPresets : id - 1, juce::sendNotification);
    };
    presetNext.onClick = [this]
    {
        const int id = presetBox.getSelectedId();
        presetBox.setSelectedId (id < 1 || id >= kNumPresets ? 1 : id + 1, juce::sendNotification);
    };
    addAndMakeVisible (presetBox);
    addAndMakeVisible (presetPrev);
    addAndMakeVisible (presetNext);

    // Tonalité : 12 boutons
    keyAtt = std::make_unique<juce::ParameterAttachment> (*proc.apvts.getParameter ("key"), [this] (float v)
    {
        const int idx = juce::roundToInt (v);
        for (int i = 0; i < 12; ++i) keyBtn[i].setToggleState (i == idx, juce::dontSendNotification);
    });
    for (int i = 0; i < 12; ++i)
    {
        keyBtn[i].setButtonText (HarmonyProcessor::pitchClassName (i));
        keyBtn[i].onClick = [this, i] { keyAtt->setValueAsCompleteGesture ((float) i); };
        addAndMakeVisible (keyBtn[i]);
    }
    keyAtt->sendInitialUpdate();

    // Gamme : 13 boutons
    scaleAtt = std::make_unique<juce::ParameterAttachment> (*proc.apvts.getParameter ("scale"), [this] (float v)
    {
        const int idx = juce::roundToInt (v);
        for (int i = 0; i < HarmonyProcessor::numScales; ++i) scaleBtn[i].setToggleState (i == idx, juce::dontSendNotification);
    });
    for (int i = 0; i < HarmonyProcessor::numScales; ++i)
    {
        scaleBtn[i].setButtonText (HarmonyProcessor::scaleName (i));
        scaleBtn[i].onClick = [this, i] { scaleAtt->setValueAsCompleteGesture ((float) i); };
        addAndMakeVisible (scaleBtn[i]);
    }
    scaleAtt->sendInitialUpdate();

    // Voix : activation + niveau
    for (int i = 0; i < HarmonyProcessor::numVoices; ++i)
    {
        voiceBtn[i].setButtonText (juce::String::fromUTF8 (kVoiceNames[i]));
        voiceBtn[i].getProperties().set ("chip", true);
        addAndMakeVisible (voiceBtn[i]);
        voiceAtt[i] = std::make_unique<BA> (proc.apvts, "v" + juce::String (i), voiceBtn[i]);

        lvSlider[i].setSliderStyle (juce::Slider::LinearHorizontal);
        lvSlider[i].setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
        addAndMakeVisible (lvSlider[i]);
        lvAtt[i] = std::make_unique<SA> (proc.apvts, "lv" + juce::String (i), lvSlider[i]);
    }

    // Boutons rotatifs : mixage, égaliseurs, compression
    for (int k = 0; k < 16; ++k)
    {
        knob[k].setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
        knob[k].setTextBoxStyle (juce::Slider::TextBoxBelow, false, 80, 18);
        addAndMakeVisible (knob[k]);
        knobAtt[k] = std::make_unique<SA> (proc.apvts, kKnobs[k].id, knob[k]);
        if (auto* rp = proc.apvts.getParameter (kKnobs[k].id))
            knob[k].setDoubleClickReturnValue (true, rp->convertFrom0to1 (rp->getDefaultValue()));
    }

    compBtn.setButtonText ("Compresseur");
    addAndMakeVisible (compBtn);
    compAtt = std::make_unique<BA> (proc.apvts, "c_on", compBtn);

    startTimerHz (24);
}

HarmonyEditor::~HarmonyEditor()
{
    stopTimer();
    setLookAndFeel (nullptr);
}

void HarmonyEditor::applyPreset (int i)
{
    const auto& p = kPresets[i];
    auto set = [this] (const juce::String& id, float real)
    {
        if (auto* prm = proc.apvts.getParameter (id))
        {
            prm->beginChangeGesture();
            prm->setValueNotifyingHost (prm->convertTo0to1 (real));
            prm->endChangeGesture();
        }
    };
    for (int v = 0; v < HarmonyProcessor::numVoices; ++v)
    {
        set ("v" + juce::String (v), ((p.mask >> v) & 1) ? 1.f : 0.f);
        set ("lv" + juce::String (v), p.lv[v] > 0.f ? p.lv[v] : 0.85f);
    }
    set ("wet", p.wet);
    set ("width", p.width);
    set ("dry", p.dry);
    const char* sfx[4] = { "lo", "lm", "hm", "hi" };
    for (int b = 0; b < 4; ++b)
    {
        set (juce::String ("m_") + sfx[b], p.mEq[b]);
        set (juce::String ("h_") + sfx[b], p.hEq[b]);
    }
    set ("c_on", 1.f);
    set ("c_thr", p.thr);
    set ("c_ratio", p.ratio);
    set ("c_att", p.att);
    set ("c_rel", p.rel);
    set ("c_mk", p.mk);
}

void HarmonyEditor::paint (juce::Graphics& g)
{
    const float w = (float) getWidth();
    g.setGradientFill (juce::ColourGradient (juce::Colour (0xff1a0d38), 0.f, 0.f,
                                             juce::Colour (0xff0a0912), 0.f, (float) getHeight(), false));
    g.fillAll();
    g.setGradientFill (juce::ColourGradient (juce::Colour (0x44ec4899), w, 0.f,
                                             juce::Colours::transparentBlack, w - 360.f, 260.f, true));
    g.fillRect (getLocalBounds());

    // En-tête : logo + « Baï-G harmonies »
    drawLogo (g, { 20.f, 14.f, 66.f, 66.f });
    g.setGradientFill (juce::ColourGradient (kGold, 98.f, 0.f, kPink, 250.f, 0.f, false));
    g.setFont (F (38.f, true));
    g.drawText (juce::String::fromUTF8 ("Baï-G"), 98, 8, 300, 44, juce::Justification::centredLeft);
    g.setColour (juce::Colours::white.withAlpha (0.9f));
    g.setFont (F (22.f));
    g.drawText ("harmonies", 100, 48, 300, 28, juce::Justification::centredLeft);

    heading (g, juce::String::fromUTF8 ("PRÉRÉGLAGES"), 500, 20, 200);

    // Titres de sections
    heading (g, juce::String::fromUTF8 ("TONALITÉ"), 20, 92, 300);
    heading (g, "GAMME", 20, 150, 300);
    heading (g, juce::String::fromUTF8 ("VOIX DU CHŒUR  ·  active une voix et règle son niveau"), 286, 228, 550);

    // Halo qui pulse avec le niveau + note détectée
    const float cx = (float) noteArea.getCentreX(), cy = (float) noteArea.getCentreY() - 8.f;
    const float rad = 52.f + lvl * 40.f;
    g.setGradientFill (juce::ColourGradient (kPink.withAlpha (0.25f + 0.4f * lvl), cx, cy,
                                             juce::Colours::transparentBlack, cx + rad, cy, true));
    g.fillEllipse (cx - rad, cy - rad, rad * 2.f, rad * 2.f);
    g.setGradientFill (juce::ColourGradient (kGold, cx - 60.f, cy, kPink, cx + 60.f, cy, false));
    g.setFont (F (64.f, true));
    g.drawText (noteText, noteArea.withTrimmedBottom (22), juce::Justification::centred);
    g.setColour (juce::Colour (0xff9a95bd));
    g.setFont (F (13.f));
    g.drawText (juce::String::fromUTF8 ("Note détectée en direct"), noteArea.withTop (noteArea.getBottom() - 24),
                juce::Justification::centred);

    // Mixage / égaliseurs / compression
    heading (g, "MIXAGE", 20, 378, 340);
    heading (g, juce::String::fromUTF8 ("VOIX PRINCIPALE · ÉGALISEUR  (120 Hz · 500 Hz · 3 kHz · 10 kHz)"), 371, 378, 469);
    heading (g, juce::String::fromUTF8 ("HARMONIES · ÉGALISEUR"), 20, 514, 360);
    heading (g, "HARMONIES · COMPRESSION", 384, 514, 190);

    g.setColour (juce::Colours::white);
    g.setFont (F (13.f, true));
    for (int k = 0; k < 16; ++k)
        g.drawText (juce::String::fromUTF8 (kKnobs[k].title), knob[k].getX(), knob[k].getY() - 17,
                    knob[k].getWidth(), 16, juce::Justification::centred);

    // Réduction de gain du compresseur
    g.setColour (kGrey);
    g.setFont (F (11.f, true));
    g.drawText ("RG", 574, 515, 24, 16, juce::Justification::centredLeft);
    const juce::Rectangle<float> bar (600.f, 520.f, 110.f, 8.f);
    g.setColour (kLine);
    g.fillRoundedRectangle (bar, 4.f);
    const float frac = juce::jlimit (0.f, 1.f, grDisp / 20.f);
    if (frac > 0.f)
    {
        g.setGradientFill (juce::ColourGradient (kGold, bar.getX(), 0.f, kPink, bar.getRight(), 0.f, false));
        g.fillRoundedRectangle (bar.withWidth (bar.getWidth() * frac), 4.f);
    }
}

void HarmonyEditor::resized()
{
    presetPrev.setBounds (500, 40, 34, 30);
    presetBox.setBounds (540, 40, 260, 30);
    presetNext.setBounds (806, 40, 34, 30);

    for (int i = 0; i < 12; ++i)
        keyBtn[i].setBounds (20 + i * 68, 110, 62, 32);

    for (int i = 0; i < HarmonyProcessor::numScales; ++i)
        scaleBtn[i].setBounds (20 + (i % 7) * 118, 168 + (i / 7) * 36, 112, 30);

    const int cw = 179;
    for (int i = 0; i < HarmonyProcessor::numVoices; ++i)
    {
        voiceBtn[i].setBounds (286 + (i % 3) * (cw + 8), 248 + (i / 3) * 64, cw, 56);
        lvSlider[i].setBounds (voiceBtn[i].getX() + 12, voiceBtn[i].getBottom() - 19, cw - 24, 14);
    }

    for (int k = 0; k < 7; ++k)
        knob[k].setBounds (20 + k * 117, 412, 117, 92);
    for (int k = 7; k < 16; ++k)
        knob[k].setBounds (20 + (k - 7) * 91, 548, 91, 92);

    compBtn.setBounds (720, 510, 120, 26);
}

void HarmonyEditor::timerCallback()
{
    const float m = proc.detectedMidi.load();
    const juce::String s = m < 0.f ? juce::String::fromUTF8 ("—") : HarmonyProcessor::noteName (m);
    bool dirty = false;
    if (s != noteText) { noteText = s; dirty = true; }

    lvl = juce::jmax (proc.level.load(), lvl * 0.88f);
    if (std::abs (lvl - lastLvl) > 0.01f) { lastLvl = lvl; dirty = true; }

    for (int i = 0; i < HarmonyProcessor::numVoices; ++i)
    {
        const juce::String n = (voiceBtn[i].getToggleState() && m >= 0.f)
                                   ? HarmonyProcessor::noteName (proc.voiceMidi[i].load())
                                   : juce::String();
        if (n != voiceBtn[i].getProperties()["note"].toString())
        {
            voiceBtn[i].getProperties().set ("note", n);
            voiceBtn[i].repaint();
        }
    }
    if (dirty) repaint (noteArea);

    grDisp = juce::jmax (proc.grMeter.load(), grDisp * 0.9f);
    if (std::abs (grDisp - lastGr) > 0.1f) { lastGr = grDisp; repaint (grArea); }
}

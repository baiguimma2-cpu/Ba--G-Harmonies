#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class BBLookAndFeel : public juce::LookAndFeel_V4
{
public:
    BBLookAndFeel();
    void drawToggleButton (juce::Graphics&, juce::ToggleButton&, bool highlighted, bool down) override;
    void drawRotarySlider (juce::Graphics&, int x, int y, int w, int h, float pos,
                           float startAngle, float endAngle, juce::Slider&) override;
    void drawLinearSlider (juce::Graphics&, int x, int y, int w, int h, float pos,
                           float minPos, float maxPos, juce::Slider::SliderStyle, juce::Slider&) override;
    void drawButtonBackground (juce::Graphics&, juce::Button&, const juce::Colour&,
                               bool highlighted, bool down) override;
    juce::Font getTextButtonFont (juce::TextButton&, int buttonHeight) override;
};

class HarmonyEditor : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit HarmonyEditor (HarmonyProcessor&);
    ~HarmonyEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;
    void applyPreset (int index);

    using BA = juce::AudioProcessorValueTreeState::ButtonAttachment;
    using SA = juce::AudioProcessorValueTreeState::SliderAttachment;

    HarmonyProcessor& proc;
    BBLookAndFeel laf;

    juce::TextButton keyBtn[12], scaleBtn[HarmonyProcessor::numScales], presetPrev, presetNext;
    juce::ComboBox presetBox;
    juce::ToggleButton voiceBtn[HarmonyProcessor::numVoices], compBtn;
    juce::Slider lvSlider[HarmonyProcessor::numVoices], knob[16];

    juce::String noteText { "—" };
    float lvl = 0.f, lastLvl = 0.f, grDisp = 0.f, lastGr = 0.f;
    const juce::Rectangle<int> noteArea { 20, 248, 250, 120 };
    const juce::Rectangle<int> grArea { 570, 508, 150, 28 };

    std::unique_ptr<juce::ParameterAttachment> keyAtt, scaleAtt;
    std::unique_ptr<BA> voiceAtt[HarmonyProcessor::numVoices], compAtt;
    std::unique_ptr<SA> lvAtt[HarmonyProcessor::numVoices], knobAtt[16];

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (HarmonyEditor)
};

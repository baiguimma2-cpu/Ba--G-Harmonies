#pragma once

// Préréglages "Baï-G harmonies", classés par contexte.
// mask : bits des voix actives (1=Unisson, 2=Tierce↑, 4=Quinte↑, 8=Octave↑, 16=Tierce↓, 32=Octave↓)
// lv : niveau de chaque voix | eq : Graves, Corps, Présence, Air (dB) | comp : seuil dB, ratio, attaque ms, relâche ms, gain dB
struct Preset
{
    const char* ctx;
    const char* name;
    int mask;
    float lv[6];
    float wet, width, dry;
    float mEq[4];
    float hEq[4];
    float thr, ratio, att, rel, mk;
};

inline const Preset kPresets[24] = {
    { "Gospel & Louange", "Chœur gospel",      30, { 0, .85f, .8f, .7f, .8f, 0 },        .85f, 1.f,  1.f, { -1, -1.5f, 1.5f, 2 },   { -3, -2, 0, 1.5f },     -20, 3.5f, 15, 160, 3 },
    { "Gospel & Louange", "Louange (worship)", 14, { 0, .8f, .75f, .7f, 0, 0 },          .8f,  .9f,  1.f, { -1, -1, 1, 2.5f },      { -4, -2, -.5f, 2 },     -22, 3,    20, 200, 3 },
    { "Gospel & Louange", "Chorale africaine", 62, { 0, .8f, .8f, .65f, .8f, .55f },     .9f,  1.f,  1.f, { -1.5f, -1, 1, 1.5f },   { -2, -1, .5f, 1 },      -20, 4,    12, 150, 3 },

    { "Afro & Antilles",  "Afrobeats backing", 18, { 0, .8f, 0, 0, .7f, 0 },             .75f, .85f, 1.f, { -2, -1, 1.5f, 2 },      { -4, -1.5f, 1, 2.5f },  -18, 4,    8,  100, 3 },
    { "Afro & Antilles",  "Afropop brillant",  22, { 0, .8f, .7f, 0, .7f, 0 },           .8f,  1.f,  1.f, { -1.5f, -1, 2, 3 },      { -3, -1, 1.5f, 3 },     -18, 3.5f, 8,  110, 3 },
    { "Afro & Antilles",  "Coupé-décalé",       9, { .6f, 0, 0, .7f, 0, 0 },             .7f,  .7f,  1.f, { -2, -1, 2, 2.5f },      { -3, 0, 2, 3 },         -16, 5,    5,  80,  4 },
    { "Afro & Antilles",  "Zouk romantique",    6, { 0, .75f, .65f, 0, 0, 0 },           .7f,  .9f,  1.f, { -1, -.5f, 1, 2 },       { -3, -1.5f, 0, 2 },     -22, 3,    18, 180, 2 },

    { "Pop & Variété",    "Pop duo",            2, { 0, .85f, 0, 0, 0, 0 },              .7f,  .8f,  1.f, { -1.5f, -1, 1.5f, 2 },   { -3, -1.5f, .5f, 2 },   -20, 3,    10, 120, 2 },
    { "Pop & Variété",    "Pop stack",         46, { 0, .8f, .7f, .6f, 0, .5f },         .85f, 1.f,  1.f, { -2, -1, 2, 3 },         { -3, -1, 1, 3 },        -18, 4,    8,  100, 3 },
    { "Pop & Variété",    "Doublage serré",     1, { .75f, 0, 0, 0, 0, 0 },              .55f, .6f,  1.f, { -1, -1, 1, 1.5f },      { -2, -1, 1, 1.5f },     -24, 2.5f, 10, 120, 1 },

    { "R&B & Soul",       "R&B velouté",       22, { 0, .7f, .65f, 0, .7f, 0 },          .75f, 1.f,  1.f, { 0, -1, 1, 2 },          { -2, -2, -.5f, 1 },     -24, 3,    25, 220, 3 },
    { "R&B & Soul",       "Néo-soul",          26, { 0, .75f, 0, .6f, .75f, 0 },         .7f,  .95f, 1.f, { .5f, -1.5f, .5f, 1.5f },{ -1, -2.5f, -1, .5f },  -22, 2.5f, 30, 250, 2 },

    { "Ballade & Acoustique", "Ballade intime", 6, { 0, .65f, .55f, 0, 0, 0 },           .55f, .8f,  1.f, { -1, -.5f, 1, 2 },       { -3, -1, -.5f, 1.5f },  -24, 2.5f, 20, 200, 1 },
    { "Ballade & Acoustique", "Folk trio",     22, { 0, .7f, .6f, 0, .65f, 0 },          .65f, .9f,  1.f, { -1, 0, 1, 1.5f },       { -2, -1, .5f, 1.5f },   -22, 2.5f, 18, 180, 1 },

    { "Rock & Live",      "Rock gang vocals",   9, { .8f, 0, 0, .8f, 0, 0 },             .9f,  .8f,  1.f, { -1, -1, 2.5f, 2 },      { -2, 0, 2.5f, 1 },      -16, 6,    5,  80,  4 },
    { "Rock & Live",      "Stade (stadium)",   62, { 0, .85f, .8f, .75f, .8f, .65f },    1.f,  1.f,  1.f, { -1, -1, 2, 3 },         { -2, -.5f, 1.5f, 2.5f },-18, 5,    6,  100, 4 },

    { "Urbain & Électro", "Hip-hop ad-libs",    8, { 0, 0, 0, .85f, 0, 0 },              .7f,  .6f,  1.f, { -2, -1, 2, 2 },         { -4, -2, 1.5f, 3 },     -14, 6,    3,  60,  4 },
    { "Urbain & Électro", "Trap octaves",      40, { 0, 0, 0, .8f, 0, .75f },            .8f,  .9f,  1.f, { -2, -1, 1, 2.5f },      { -1, -2, 1, 3 },        -16, 6,    4,  70,  4 },
    { "Urbain & Électro", "Électro vocal",     14, { 0, .8f, .8f, .8f, 0, 0 },           .9f,  1.f,  1.f, { -2, -1.5f, 1.5f, 3 },   { -3, -2, 2, 4 },        -14, 8,    2,  60,  5 },

    { "Cinéma & Ambiance", "Ange éthéré",      14, { 0, .7f, .65f, .8f, 0, 0 },          .95f, 1.f,  1.f, { -1, -.5f, .5f, 3 },     { -6, -3, 0, 4 },        -26, 2,    40, 300, 1 },
    { "Cinéma & Ambiance", "Cinéma profond",   49, { .6f, 0, 0, 0, .8f, .85f },          .85f, .9f,  1.f, { 0, -1, .5f, 1.5f },     { 2, -1, -2, -1 },       -22, 3,    20, 250, 2 },
    { "Cinéma & Ambiance", "Mystique",         42, { 0, .7f, 0, .7f, 0, .7f },           .85f, 1.f,  1.f, { -1, -1, .5f, 2 },       { -1, -3, -1, 2 },       -24, 2.5f, 30, 260, 2 },

    { "Reggae & Dancehall", "Reggae roots",     6, { 0, .7f, .6f, 0, 0, 0 },             .65f, .8f,  1.f, { 0, -1, 1, 1.5f },       { -1, -1, .5f, 1 },      -20, 3,    15, 150, 2 },
    { "Reggae & Dancehall", "Dancehall",       10, { 0, .8f, 0, .7f, 0, 0 },             .75f, .8f,  1.f, { -2, -1, 2, 2.5f },      { -3, 0, 1.5f, 3 },      -16, 5,    5,  90,  3 }
};

inline constexpr int kNumPresets = 24;

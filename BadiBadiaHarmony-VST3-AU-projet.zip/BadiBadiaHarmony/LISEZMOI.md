# Baï-G harmonies — plugin VST3 / AU (v1.1)

Génère jusqu'à 6 voix d'harmonie à partir d'une seule voix, calées sur la tonalité et la gamme choisies.

## Nouveautés v1.1
- **Tonalité** : 12 boutons (Do à Si).
- **Gamme** : 13 boutons — Majeur, Mineur, Mineur harmonique, Mineur mélodique, Dorien, Phrygien, Lydien, Mixolydien, Pentatonique majeure/mineure, Blues, Hijaz (arabe), Chromatique.
- **24 préréglages** classés par contexte : Gospel & Louange, Afro & Antilles, Pop & Variété, R&B & Soul, Ballade & Acoustique, Rock & Live, Urbain & Électro, Cinéma & Ambiance, Reggae & Dancehall. Flèches < > pour les parcourir.
- **Niveau de chaque voix** (curseur sous chaque voix).
- **Égaliseur 4 bandes indépendant** pour la voix principale ET pour les harmonies : Graves (120 Hz), Corps (500 Hz), Présence (3 kHz), Air (10 kHz), ±12 dB. Double-clic sur un bouton = retour à zéro.
- **Compresseur des harmonies** : Seuil, Ratio, Attaque, Relâche, Gain, bouton marche/arrêt et témoin de réduction de gain (RG).
- **Nouveau logo « Baï-G harmonies »** : monogramme B + G, le G a une barre en forme d'onde et deux anneaux fantômes qui représentent les harmonies.

## Mise à jour sur GitHub
1. Dans ton dépôt : **Add file → Upload files**, choisis le nouveau zip **avec le même nom** `BadiBadiaHarmony-VST3-AU-projet.zip` (il remplace l'ancien).
2. **Commit changes**. La compilation redémarre toute seule (onglet Actions).
3. Télécharge le résultat dans **Artifacts**.

## Installation (FL Studio, Windows)
Copie `Badi-badia Harmony.vst3` dans `C:\Program Files\Common Files\VST3`, puis dans FL Studio : **Options → Manage plugins → Find installed plugins**.

## Licence JUCE
JUCE est gratuit pour un usage personnel / open source (AGPLv3) ; la vente d'un plugin fermé demande une licence JUCE (juce.com/get-juce).
